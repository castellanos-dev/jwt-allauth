"""
Management commands for JWT Allauth
""" 