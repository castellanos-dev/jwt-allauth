"""
Django management commands for JWT Allauth
""" 